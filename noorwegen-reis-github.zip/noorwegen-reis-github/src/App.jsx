import { useMemo, useState, useEffect } from "react";
import { initialTrip } from "./tripData";
import "./style.css";

const typeColors = {
  wandelen: { icon: "🥾", label: "Wandelen" },
  water: { icon: "🏊", label: "Water" },
  kayak: { icon: "🛶", label: "Kayak/kano" },
  fiets: { icon: "🚵", label: "Fietsen" },
  vissen: { icon: "🎣", label: "Vissen" },
  rijden: { icon: "🚗", label: "Toerrit" },
  cultuur: { icon: "🏛️", label: "Cultuur" },
};

const priorityLabels = {
  must: "⭐ Must-do",
  leuk: "👍 Leuk",
  regenoptie: "☔ Regenoptie",
  extra: "➕ Extra",
};

function keyFor(legId, activityName, field) {
  return `noorwegen:${legId}:${activityName}:${field}`;
}

function ActivityBadge({ type }) {
  const c = typeColors[type] || { icon: "✦", label: type };
  return <span className={`badge badge-${type}`}>{c.icon} {c.label}</span>;
}

function LinkButton({ href, children }) {
  if (!href) return null;
  return <a className="linkButton" href={href} target="_blank" rel="noreferrer">{children}</a>;
}

function ActivityCard({ legId, activity }) {
  const [done, setDone] = useState(() => localStorage.getItem(keyFor(legId, activity.name, "done")) === "true");
  const [note, setNote] = useState(() => localStorage.getItem(keyFor(legId, activity.name, "note")) || "");

  useEffect(() => localStorage.setItem(keyFor(legId, activity.name, "done"), String(done)), [done, legId, activity.name]);
  useEffect(() => localStorage.setItem(keyFor(legId, activity.name, "note"), note), [note, legId, activity.name]);

  return (
    <article className={`activityCard ${done ? "done" : ""}`}>
      <div className="activityTop">
        <div>
          <div className="activityTitleRow">
            <ActivityBadge type={activity.type} />
            <strong>{activity.name}</strong>
          </div>
          <div className="metaRow">
            {activity.priority && <span>{priorityLabels[activity.priority] || activity.priority}</span>}
            {activity.duration && <span>⏱ {activity.duration}</span>}
            {activity.distance && <span>📏 {activity.distance}</span>}
            {activity.difficulty && <span>🥾 {activity.difficulty}</span>}
            {activity.weather && <span>🌦 {activity.weather}</span>}
          </div>
        </div>
        <label className="check">
          <input type="checkbox" checked={done} onChange={(e) => setDone(e.target.checked)} />
          gedaan
        </label>
      </div>
      <p>{activity.desc}</p>
      <div className="buttons">
        <LinkButton href={activity.komoot}>🧭 Komoot</LinkButton>
        <LinkButton href={activity.maps}>📍 Maps</LinkButton>
        <LinkButton href={activity.website}>🌐 Info/boeken</LinkButton>
      </div>
      <textarea
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Eigen notitie, parkeerinfo, tip, prijs..."
        rows={2}
      />
    </article>
  );
}

function StopCard({ leg, globalFilter, priorityFilter }) {
  const [open, setOpen] = useState(true);
  const [localType, setLocalType] = useState("alle");

  const types = [...new Set(leg.activities.map(a => a.type))];
  const filtered = leg.activities.filter(a => {
    const typeOk = globalFilter === "alle" && localType === "alle"
      ? true
      : (globalFilter !== "alle" ? a.type === globalFilter : a.type === localType);
    const prioOk = priorityFilter === "alle" ? true : a.priority === priorityFilter;
    return typeOk && prioOk;
  });

  return (
    <section className="stopCard">
      <button className="stopHeader" onClick={() => setOpen(!open)}>
        <span>
          <strong>{leg.label}</strong>
          <em>{leg.date}</em>
          {leg.arrival && <small>aankomst {leg.arrival}</small>}
        </span>
        <span>{open ? "▲" : "▼"}</span>
      </button>

      {open && (
        <div className="stopBody">
          <p className="note">{leg.note}</p>

          <details className="facts" open>
            <summary>💡 Weetjes & context</summary>
            <ul>{leg.facts?.map((f, i) => <li key={i}>{f}</li>)}</ul>
          </details>

          <div className="localFilters">
            <button className={localType === "alle" ? "active" : ""} onClick={() => setLocalType("alle")}>✦ alle</button>
            {types.map(t => <button key={t} className={localType === t ? "active" : ""} onClick={() => setLocalType(t)}>{typeColors[t]?.icon} {t}</button>)}
          </div>

          <div className="sectionTitle">🏃 Activiteiten ({filtered.length}/{leg.activities.length})</div>
          <div className="activityList">
            {filtered.map((a) => <ActivityCard key={a.name} legId={leg.id} activity={a} />)}
          </div>

          <div className="sectionTitle food">🍽️ Restaurants / eten</div>
          <div className="restaurantGrid">
            {leg.restaurants.map(r => (
              <article className="restaurant" key={r.name}>
                <strong>{r.name}</strong>
                <p>{r.desc}</p>
                <LinkButton href={r.maps}>📍 Maps</LinkButton>
              </article>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}

export default function App() {
  const [globalFilter, setGlobalFilter] = useState("alle");
  const [priorityFilter, setPriorityFilter] = useState("alle");

  const stats = useMemo(() => {
    const activities = initialTrip.legs.flatMap(l => l.activities);
    return {
      stops: initialTrip.legs.length,
      total: activities.length,
      must: activities.filter(a => a.priority === "must").length,
      hikes: activities.filter(a => a.type === "wandelen").length,
      rain: activities.filter(a => a.priority === "regenoptie" || a.weather === "regenoptie").length,
      done: activities.filter(a => localStorage.getItem(keyFor(initialTrip.legs.find(l => l.activities.includes(a))?.id, a.name, "done")) === "true").length
    };
  }, []);

  const globalTypes = ["alle", ...Object.keys(typeColors)];

  return (
    <main>
      <header className="hero">
        <div className="eyebrow">Reis-app · deelbaar via GitHub Pages</div>
        <h1>🇳🇴 {initialTrip.title}</h1>
        <p>{initialTrip.subtitle}</p>
        <div className="stats">
          <span>📍 {stats.stops} stops</span>
          <span>🏃 {stats.total} activiteiten</span>
          <span>⭐ {stats.must} must-do's</span>
          <span>🥾 {stats.hikes} wandelingen</span>
          <span>☔ {stats.rain} regenopties</span>
        </div>
      </header>

      <section className="routeBox">
        <strong>🗺️ Route</strong><br />
        {initialTrip.route}
      </section>

      <section className="toolbar">
        <div>
          <label>Type</label>
          <select value={globalFilter} onChange={(e) => setGlobalFilter(e.target.value)}>
            {globalTypes.map(t => <option key={t} value={t}>{t === "alle" ? "Alle types" : `${typeColors[t]?.icon || ""} ${typeColors[t]?.label || t}`}</option>)}
          </select>
        </div>
        <div>
          <label>Prioriteit</label>
          <select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)}>
            <option value="alle">Alles</option>
            <option value="must">⭐ Must-do</option>
            <option value="leuk">👍 Leuk</option>
            <option value="regenoptie">☔ Regenoptie</option>
            <option value="extra">➕ Extra</option>
          </select>
        </div>
      </section>

      {initialTrip.legs.map(leg => <StopCard key={leg.id} leg={leg} globalFilter={globalFilter} priorityFilter={priorityFilter} />)}

      <footer>
        Controleer openingstijden, ferry’s, weer, vergunningen en boekbaarheid kort voor vertrek. Notities en vinkjes worden lokaal op je iPhone bewaard.
      </footer>
    </main>
  );
}
