export const initialTrip = {
  "title": "Noorwegen Zomerreis 2026",
  "subtitle": "16 juni – 30 juni · Auto + Ferry · Self-catering",
  "route": "NL → Hirtshals ⛴️ → Bergen → Sogndal → Skjåk → Valdres/Fagernes → Gjerstad → Kristiansand ⛴️ → Hirtshals → Kolding → NL",
  "legs": [
    {
      "id": "sogndal",
      "label": "📍 Sogndal",
      "date": "16–18 jun",
      "arrival": "16 jun, 18:00",
      "note": "Sogndal ligt aan de Sognefjord: goede uitvalsbasis voor fjord, gletsjer, fietsen, SUP en rustige avondwandelingen.",
      "facts": [
        "Sognefjord is de langste fjord van Noorwegen.",
        "Fjærland staat bekend als boekendorp en toegangspoort tot Jostedalsbreen.",
        "Urnes Stavkerk aan de overkant van de fjord staat op de UNESCO Werelderfgoedlijst."
      ],
      "activities": [
        {
          "name": "SUP / Paddleboarden op de Sognefjord",
          "type": "water",
          "priority": "leuk",
          "weather": "zon",
          "duration": "1–2 uur",
          "difficulty": "makkelijk",
          "desc": "Paddleboarden op kalm fjordwater. Beginnersvriendelijk, maar kleed je warm: water is in juni koud.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Sogndal+harbour+paddleboard",
          "website": "https://www.sognefjord.no/en"
        },
        {
          "name": "Begeleide kayaktocht op de fjord",
          "type": "kayak",
          "priority": "must",
          "weather": "droog",
          "duration": "2,5 uur",
          "difficulty": "makkelijk-matig",
          "desc": "Geleide tocht op rustig fjordwater. Vooraf boeken is verstandig in juni.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Dampskipskaien+Sogndal+kayak",
          "website": "https://www.sognefjord.no/en"
        },
        {
          "name": "FjordX e-bike & bootrondvaart",
          "type": "fiets",
          "priority": "leuk",
          "weather": "droog",
          "duration": "halve dag",
          "distance": "±22 km fietsen",
          "difficulty": "makkelijk",
          "desc": "Boot de fjord op, daarna per e-bike terug langs lichte wegen en paden. Fijne combi van natuur en lichte sport.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Sogndal+harbour",
          "website": "https://www.sognefjord.no/en"
        },
        {
          "name": "Wandelen: Bøyabreen gletsjer",
          "type": "wandelen",
          "priority": "must",
          "weather": "kan-altijd",
          "duration": "30–60 min",
          "distance": "kort",
          "difficulty": "makkelijk",
          "desc": "Makkelijk pad naar uitzicht op de gletsjertong van Jostedalsbreen. Vroeg gaan om touringcars voor te zijn.",
          "komoot": "https://www.komoot.com/search/Bøyabreen%20glacier%20walk",
          "maps": "https://www.google.com/maps/search/?api=1&query=Bøyabreen+Glacier+parking+Fjærland",
          "website": "https://www.nasjonalparkstyre.no/Jostedalsbreen"
        },
        {
          "name": "Gletsjerwandeling Nigardsbreen",
          "type": "wandelen",
          "priority": "must",
          "weather": "droog",
          "duration": "3–5 uur",
          "difficulty": "matig",
          "desc": "Dagtrip richting Jostedalen. Professionele gids en vaak boot over het gletsjermeer. Boek vooraf en controleer condities.",
          "komoot": "https://www.komoot.com/search/Nigardsbreen%20glacier%20hike",
          "maps": "https://www.google.com/maps/search/?api=1&query=Breheimsenteret+Nigardsbreen",
          "website": "https://www.bfl.no/"
        },
        {
          "name": "Kaupanger Stavkerk + fjordwandeling",
          "type": "cultuur",
          "priority": "leuk",
          "weather": "regenoptie",
          "duration": "1–2 uur",
          "difficulty": "makkelijk",
          "desc": "Goed bewaarde stavkerk vlakbij Sogndal. Combineer met een rustige wandeling langs de fjord bij Kaupanger.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Kaupanger+Stavkirke",
          "website": "https://www.stavechurch.com/kaupanger-stave-church/"
        },
        {
          "name": "Fjord zwemmen bij rustige baai",
          "type": "water",
          "priority": "extra",
          "weather": "zon",
          "duration": "30 min",
          "difficulty": "makkelijk",
          "desc": "Koud maar verfrissend. Vraag lokaal naar veilige instapplekken; vermijd stroming en bootverkeer.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Sogndal+fjord+beach+swimming"
        }
      ],
      "restaurants": [
        {
          "name": "Dampskipskaien",
          "desc": "Aan het water; praktisch voor aankomst en toeristische info.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Dampskipskaien+Sogndal"
        },
        {
          "name": "Restauranthuset Malin",
          "desc": "Lokale Noorse smaken, goede sfeer.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Restauranthuset+Malin+Sogndal"
        }
      ]
    },
    {
      "id": "skjak",
      "label": "📍 Skjåk",
      "date": "19–22 jun",
      "arrival": "19 jun",
      "note": "Skjåk ligt tussen Breheimen en Reinheimen. Droog microklimaat, ruige dalen, rafting en stille bergwandelingen.",
      "facts": [
        "Skjåk wordt vaak genoemd als een van de droogste gebieden van Noorwegen.",
        "De Otta-rivier maakt de streek interessant voor rafting en vissen.",
        "Breheimen betekent letterlijk ‘thuis van de gletsjers’."
      ],
      "activities": [
        {
          "name": "Raften op de Otta-rivier",
          "type": "water",
          "priority": "must",
          "weather": "droog",
          "duration": "2–4 uur",
          "difficulty": "matig",
          "desc": "Begeleide wildwatertocht via Lom & Skjåk Adventure. Boek vooraf; kies niveau afhankelijk van waterstand.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Skjåk+Adventure+rafting",
          "website": "https://www.skjak-adventure.no/"
        },
        {
          "name": "Wandelen: Dønfoss → Gjelbrue / Tundragjelet",
          "type": "wandelen",
          "priority": "must",
          "weather": "droog",
          "duration": "2–3 uur",
          "difficulty": "matig",
          "desc": "Start rond Dønfoss, via dennenbos richting brug en kloof. Neem water mee; weinig voorzieningen onderweg.",
          "komoot": "https://www.komoot.com/search/Dønfoss%20Gjelbrue%20Tundragjelet",
          "maps": "https://www.google.com/maps/search/?api=1&query=Dønfoss+Skjåk",
          "website": "https://ut.no/"
        },
        {
          "name": "Wandelen: Sota Sæter → Breheimen",
          "type": "wandelen",
          "priority": "leuk",
          "weather": "droog",
          "duration": "3 uur tot dagtocht",
          "difficulty": "matig-zwaar",
          "desc": "DNT-hut als startpunt voor stille bergtochten. Kaart/offline route nodig.",
          "komoot": "https://www.komoot.com/search/Sota%20Sæter%20Breheimen%20hike",
          "maps": "https://www.google.com/maps/search/?api=1&query=Sota+Sæter",
          "website": "https://sotaseter.dnt.no/"
        },
        {
          "name": "Vissen op de Otta-rivier",
          "type": "vissen",
          "priority": "extra",
          "weather": "kan-altijd",
          "duration": "1–3 uur",
          "difficulty": "makkelijk",
          "desc": "Forelvisserij langs de Otta. Visvergunning regelen voor vertrek of lokaal.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Otta+river+Skjåk+fishing",
          "website": "https://www.inatur.no/"
        },
        {
          "name": "Gletsjerwandeling Spørteggbreen / Jostedalen",
          "type": "wandelen",
          "priority": "leuk",
          "weather": "droog",
          "duration": "dagtrip",
          "difficulty": "zwaar",
          "desc": "Minder bekend gletsjergebied. Alleen met gids op het ijs.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Jostedalen+Breførarlag",
          "website": "https://www.bfl.no/"
        },
        {
          "name": "Sognefjellsvegen nationale toeristische route",
          "type": "rijden",
          "priority": "must",
          "weather": "droog",
          "duration": "halve-dag/dag",
          "difficulty": "makkelijk",
          "desc": "Spectaculaire bergweg langs Jotunheimen. Stop bij uitzichtpunten en Grotli of Lom voor koffie.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Sognefjellsvegen+scenic+route",
          "website": "https://www.nasjonaleturistveger.no/en/routes/sognefjellet/"
        },
        {
          "name": "Seppalatunet museum in Bismo",
          "type": "cultuur",
          "priority": "regenoptie",
          "weather": "regenoptie",
          "duration": "1 uur",
          "difficulty": "makkelijk",
          "desc": "Klein museum over Leonhard Seppala, poolgeschiedenis en sledemushing.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Seppalatunet+Bismo",
          "website": "https://www.visitjotunheimen.no/"
        }
      ],
      "restaurants": [
        {
          "name": "Grotli Høyfjellshotell",
          "desc": "Fjellhotel op hoogte; mooi voor koffie/lunch tijdens rit.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Grotli+Høyfjellshotell"
        },
        {
          "name": "Bismo centrum café",
          "desc": "Beperkt aanbod, maar praktisch en lokaal.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Bismo+Skjåk+cafe"
        }
      ]
    },
    {
      "id": "valdres",
      "label": "📍 Valdres (Fagernes / Nord-Aurdal)",
      "date": "23–26 jun",
      "arrival": "23 jun",
      "note": "Valdres is de streek; Nord-Aurdal is de gemeente en Fagernes het praktische centrum. Goede basis voor Besseggen, Mjølkevegen, Bygdin en rustige meren.",
      "facts": [
        "Valdres is bekend om stølslandschap, brunost en bergboerderijen.",
        "Fagernes ligt centraal aan Strondafjorden.",
        "Besseggen ligt niet in Nord-Aurdal zelf, maar is goed als dagtrip vanuit Valdres."
      ],
      "activities": [
        {
          "name": "Wandelen: Besseggen Ridge ⭐",
          "type": "wandelen",
          "priority": "must",
          "weather": "droog",
          "duration": "6–8 uur",
          "distance": "14–18 km",
          "difficulty": "zwaar",
          "desc": "Klassieke graatwandeling tussen Gjende en Bessvatnet. Vroeg vertrekken en ferry vooraf boeken. Niet doen bij slecht zicht of harde wind.",
          "komoot": "https://www.komoot.com/discover/Besseggen",
          "maps": "https://www.google.com/maps/search/?api=1&query=Gjendesheim+Besseggen+parking",
          "website": "https://www.gjende.no/"
        },
        {
          "name": "Wandelen: Bjørgovarden",
          "type": "wandelen",
          "priority": "leuk",
          "weather": "droog",
          "duration": "2–3 uur",
          "distance": "±7 km",
          "difficulty": "makkelijk-matig",
          "desc": "Rustiger alternatief met breed panorama over Valdres. Goede ochtendwandeling.",
          "komoot": "https://www.komoot.com/search/Bjørgovarden%20Valdres%20hike",
          "maps": "https://www.google.com/maps/search/?api=1&query=Bjørgovarden+Aurdal"
        },
        {
          "name": "Vissen op Aurdalsfjorden",
          "type": "vissen",
          "priority": "extra",
          "weather": "kan-altijd",
          "duration": "1–3 uur",
          "difficulty": "makkelijk",
          "desc": "Forel/baars. Informeer bij camping of lokale vergunning via Inatur.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Aurdalsfjorden+fishing",
          "website": "https://www.inatur.no/"
        },
        {
          "name": "Fietsen: Valdresbanevegen",
          "type": "fiets",
          "priority": "leuk",
          "weather": "droog",
          "duration": "2–4 uur",
          "difficulty": "makkelijk",
          "desc": "Vlakke fietsroute over oude spoorlijn richting Fagernes. Fijn als lichte dag na zware hike.",
          "komoot": "https://www.komoot.com/search/Valdresbanevegen%20cycling%20Fagernes",
          "maps": "https://www.google.com/maps/search/?api=1&query=Valdresbanen+Fagernes"
        },
        {
          "name": "Kano / kayak op Aurdalsfjorden",
          "type": "kayak",
          "priority": "leuk",
          "weather": "zon",
          "duration": "1–2 uur",
          "difficulty": "makkelijk",
          "desc": "Rustig meerwater, goed voor beginners. Check verhuur bij camping/accommodatie.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Aurdal+Fjordcamping+canoe"
        },
        {
          "name": "M/S Bitihorn boottocht op Bygdin",
          "type": "water",
          "priority": "must",
          "weather": "droog",
          "duration": "2–4 uur",
          "difficulty": "makkelijk",
          "desc": "Hooggelegen boottocht over Bygdin tussen bergen. Boek vooraf in hoogseizoen.",
          "maps": "https://www.google.com/maps/search/?api=1&query=M/S+Bitihorn+Bygdin",
          "website": "https://jvb.no/"
        },
        {
          "name": "Mjølkevegen per fiets of auto",
          "type": "rijden",
          "priority": "must",
          "weather": "droog",
          "duration": "halve dag/dag",
          "difficulty": "makkelijk-matig",
          "desc": "Stølsroute door open landschap met bergboerderijen. Wafels en brunost onderweg scoren.",
          "komoot": "https://www.komoot.com/search/Mjølkevegen%20Valdres%20cycling",
          "maps": "https://www.google.com/maps/search/?api=1&query=Mjølkevegen+Valdres",
          "website": "https://www.valdres.no/"
        },
        {
          "name": "Valdres Folkemuseum",
          "type": "cultuur",
          "priority": "regenoptie",
          "weather": "regenoptie",
          "duration": "1–3 uur",
          "difficulty": "makkelijk",
          "desc": "Openluchtmuseum bij Fagernes. Goede regendag-optie en cultuur zonder veel rijden.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Valdres+Folkemuseum+Fagernes",
          "website": "https://valdresmusea.no/"
        }
      ],
      "restaurants": [
        {
          "name": "Restaurant Valdres / Scandic Valdres",
          "desc": "Praktisch in Fagernes met uitzicht over het water.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Scandic+Valdres+restaurant"
        },
        {
          "name": "Danebu Kongsgaard",
          "desc": "Mooie plek boven Aurdal; reserveren slim.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Danebu+Kongsgaard"
        }
      ]
    },
    {
      "id": "gjerstad",
      "label": "📍 Gjerstad (Agder)",
      "date": "27–28 jun",
      "arrival": "27 jun",
      "note": "Bosrijk Zuid-Noorwegen, rustig en minder toeristisch. Goed als laatste natuur/rust-stop, met Risør en Tvedestrand dichtbij.",
      "facts": [
        "Sørlandet staat bekend om witte houten kustplaatsen.",
        "In de bossen rond Gjerstad is de kans op elanden groter dan in drukke toeristengebieden.",
        "Risør wordt vaak ‘den hvite by ved Skagerrak’ genoemd."
      ],
      "activities": [
        {
          "name": "Wandelen: Solhomfjell",
          "type": "wandelen",
          "priority": "must",
          "weather": "droog",
          "duration": "3 uur",
          "distance": "±11 km",
          "difficulty": "matig",
          "desc": "Panoramische wandeling vanuit Sandtjønn-omgeving. Neem lunch en water mee.",
          "komoot": "https://www.komoot.com/search/Solhomfjell%20Gjerstad%20hike",
          "maps": "https://www.google.com/maps/search/?api=1&query=Solhomfjell+Gjerstad+parking"
        },
        {
          "name": "Wandelen: Havrefjell",
          "type": "wandelen",
          "priority": "leuk",
          "weather": "droog",
          "duration": "2 uur",
          "distance": "±6,5 km",
          "difficulty": "matig",
          "desc": "Korter alternatief met wijd uitzicht. Goed te combineren met Risør of Tvedestrand.",
          "komoot": "https://www.komoot.com/search/Havrefjell%20Gjerstad%20hike",
          "maps": "https://www.google.com/maps/search/?api=1&query=Havrefjell+Gjerstad"
        },
        {
          "name": "Zwemmen in Gjerstadvatnet",
          "type": "water",
          "priority": "extra",
          "weather": "zon",
          "duration": "30–60 min",
          "difficulty": "makkelijk",
          "desc": "Rustig zoetwatermeer. Check lokaal veilige instapplek.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Gjerstadvatnet+swimming"
        },
        {
          "name": "Kanoën op Gjerstadvatnet",
          "type": "kayak",
          "priority": "extra",
          "weather": "zon",
          "duration": "1–2 uur",
          "difficulty": "makkelijk",
          "desc": "Geen gegarandeerde verhuur; vraag accommodatie of neem eigen opblaasbare kajak mee.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Gjerstadvatnet"
        },
        {
          "name": "Dagtrip: kayakken rond Risør",
          "type": "kayak",
          "priority": "leuk",
          "weather": "droog",
          "duration": "halve dag",
          "difficulty": "matig",
          "desc": "Mooie scherenkust met eilandjes. Let op wind; kustwater is minder vergevingsgezind dan een meer.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Risør+kayak+rental",
          "website": "https://www.visitsorlandet.com/"
        },
        {
          "name": "Dagtrip: Tvedestrand & Risør",
          "type": "rijden",
          "priority": "must",
          "weather": "kan-altijd",
          "duration": "halve dag",
          "difficulty": "makkelijk",
          "desc": "Witte houten huisjes, haven, koffie en kustsfeer. Sterke afsluiter van de reis.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Risør+Tvedestrand+scenic+drive"
        },
        {
          "name": "Vissen rond Gjerstad",
          "type": "vissen",
          "priority": "extra",
          "weather": "kan-altijd",
          "duration": "1–3 uur",
          "difficulty": "makkelijk",
          "desc": "Veel meren met forel/baars. Vergunning via Inatur of lokaal regelen.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Gjerstad+fishing",
          "website": "https://www.inatur.no/"
        }
      ],
      "restaurants": [
        {
          "name": "Havenrestaurant in Risør",
          "desc": "Kustsfeer en verse vis/vega opties zoeken ter plekke.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Risør+harbour+restaurant"
        },
        {
          "name": "Brokelandheia",
          "desc": "Praktische stop langs E18.",
          "maps": "https://www.google.com/maps/search/?api=1&query=Brokelandheia+restaurant"
        }
      ]
    }
  ]
};
