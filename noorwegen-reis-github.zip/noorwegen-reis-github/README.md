# Noorwegen Reisplanner 2026

Mobiele reis-app voor iPhone met:
- filters op type activiteit en prioriteit
- Komoot-/Google Maps-/info-links
- checkboxes voor “gedaan”
- eigen notities per activiteit
- weetjes per regio
- GitHub Pages workflow

## Openen op iPhone

Na publicatie via GitHub Pages:
1. Open de site in Safari.
2. Tik op delen.
3. Kies **Zet op beginscherm**.

## Aanpassen

De reisdata staat in:

```text
src/tripData.js
```

Voeg activiteiten toe door een nieuw object in `activities` te zetten.

## GitHub Pages

Deze repo bevat al `.github/workflows/deploy.yml`.
Zet in GitHub onder **Settings → Pages → Build and deployment** de source op **GitHub Actions**.
Daarna wordt de site automatisch gepubliceerd bij iedere push naar `main`.

## Let op

Controleer kort voor vertrek:
- ferry’s
- gidsen/boekingen
- openingstijden
- weer
- wandelcondities
- visvergunningen
